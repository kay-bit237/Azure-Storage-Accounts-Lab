# Microsoft Azure — Storage Accounts Implementation

> **Domain:** Cloud Infrastructure & Data Management | **Platform:** Microsoft Azure | **Level:** Foundational

---

## Executive Summary

This project documents the creation and configuration of Azure Storage Accounts as part of a structured Microsoft Azure cloud training program. The exercise explored how cloud storage works beneath the surface — covering redundancy models, availability options, security configurations, and data durability — demonstrating that storage infrastructure is far more strategic than it first appears.

---

## Objectives

- Provision and configure Azure Storage Accounts within a cloud environment
- Understand the role of storage as the backbone of cloud data infrastructure
- Evaluate redundancy and availability options to ensure data durability
- Apply baseline security configurations to protect stored data
- Review Azure Advisor recommendations to identify and assess security findings
- Recognize how foundational storage decisions impact long-term cloud architecture

---

## Environment & Technologies

| Component | Description |
|---|---|
| **Microsoft Azure** | Cloud hosting and administration platform |
| **Azure Storage Accounts** | Scalable cloud storage for files, images, backups, and application data |
| **Azure Portal** | Web-based interface used for provisioning and configuration |
| **Redundancy Models** | LRS, ZRS, GRS, GZRS, RA-GRS — controlling availability and durability of stored data |
| **Azure Advisor** | Built-in tool providing security and reliability recommendations |
| **Diagnostic Settings** | Logging and monitoring configuration for storage resources |

---

## What is an Azure Storage Account?

An Azure Storage Account is the foundational unit of cloud storage in Microsoft Azure. It serves as a centralized container for storing virtually any type of data — files, images, backups, logs, and application data — in a secure, scalable, and highly available environment.

What makes it more than "just storage" is the control it gives you:
- **You define how available your data should be** — choosing between local, zone, or geo-redundant storage
- **You define how durable it should be** — built-in redundancy protects data even in the event of hardware or regional failures
- **You control who can access it** — security settings at the account level govern exposure of sensitive information

---

## Implementation

### Phase 1 — Storage Account Provisioning

Two Storage Accounts were created in the Azure Portal under different resource groups and regions:

| Storage Account | Type | Resource Group | Location |
|---|---|---|---|
| **storagelab1212** | StorageV2 | cyberpotential | East US 2 |
| **workshoplab** | Storage | NetworkWatcherRG | East US |

**Screenshot — All Storage Accounts Created:**

![Storage Accounts Overview](assets/storage-accounts-overview.png)

---

**Screenshot — storagela1 Account Overview:**

![storagela1 Overview](assets/storagela1-overview.png)

> **Note:** The overview confirms RA-GRS replication, Standard performance tier, StorageV2 account kind, with both Primary (East US 2) and Secondary (Central US) locations showing as Available.

---

### Phase 2 — Redundancy & Availability Configuration

#### What is Redundancy?
Redundancy means Azure automatically makes **multiple copies of your data** to protect it from being lost if something fails — whether that's a hard drive, a building, or an entire region. The redundancy model chosen at provisioning directly determines how resilient your data is.

---

#### 🟢 LRS — Locally Redundant Storage
- **What it does:** Makes **3 copies** of your data within the **same datacenter**
- **Think of it as:** 3 USB drives stored in the same room
- **Protected against:** Individual hard drive or server failure
- **NOT protected against:** Fire, flood, or power outage affecting the entire building
- **Best for:** Dev/test environments, non-critical data
- **Cost:** $ — Cheapest option

---

#### 🔵 ZRS — Zone Redundant Storage
- **What it does:** Makes **3 copies** spread across **3 different availability zones** in the same region
- **Think of it as:** 3 USB drives stored in 3 different buildings in the same city
- **Protected against:** One entire datacenter or availability zone going down
- **Best for:** Applications requiring high availability and uptime
- **Cost:** $$ — Mid-range

---

#### 🟡 GRS — Geo Redundant Storage
- **What it does:** Makes **6 copies** — 3 in your primary region and 3 in a **completely different region** (e.g. East US → West US)
- **Think of it as:** 3 USB drives in New York AND 3 USB drives in California
- **Protected against:** An entire region going down due to natural disaster or major outage
- **Best for:** Business-critical data that must survive regional failures
- **Cost:** $$$ — Higher

---

#### 🔴 GZRS — Geo-Zone Redundant Storage
- **What it does:** Combines ZRS + GRS — copies spread across **multiple zones AND multiple regions**
- **Think of it as:** The best of both worlds — zone resilience plus geographic separation
- **Protected against:** Both zone-level and region-level failures
- **Best for:** Enterprise-critical data requiring maximum durability
- **Cost:** $$$$ — Most expensive

---

#### 🟠 RA-GRS — Read-Access Geo-Redundant Storage
- **What it does:** Same as GRS but also allows **read access** to the secondary region at all times
- **Think of it as:** GRS + the ability to read your backup copy even before a failover
- **Protected against:** Regional failures, with added read availability during outages
- **Best for:** Applications that need continuous read access even during a primary region failure
- **Cost:** $$$$ — Similar to GZRS

> **This project used RA-GRS** — confirming data is replicated across East US 2 (Primary) and Central US (Secondary), both showing Available status.

---

#### Redundancy Comparison

| Model | Copies | Location | Best For | Cost |
|---|---|---|---|---|
| **LRS** | 3 | Same datacenter | Dev/test | $ |
| **ZRS** | 3 | 3 zones, same region | High availability | $$ |
| **GRS** | 6 | 2 different regions | Business-critical | $$$ |
| **GZRS** | 6+ | Zones + 2 regions | Maximum durability | $$$$ |
| **RA-GRS** | 6 | 2 regions + read access | Read-heavy critical apps | $$$$ |

**Screenshot — Redundancy Configuration (RA-GRS):**

![Redundancy Settings](assets/storagela1-redundancy.png)

---

### Phase 3 — Security Configuration

Baseline security settings were reviewed and applied to protect stored data:

| Security Setting | Configuration | Purpose |
|---|---|---|
| **Secure Transfer Required** | Enabled | Enforces HTTPS for all data transfers |
| **Blob Anonymous Access** | Disabled | Prevents unauthorized public access to blob data |
| **Storage Account Key Access** | Enabled | Allows programmatic access via account keys |
| **Minimum TLS Version** | 1.2 | Ensures encrypted, up-to-date communication |
| **SAS Expiry Interval** | Disabled | Controls shared access signature time limits |
| **Default to Entra Authorization** | Disabled | Controls identity-based access in the portal |
| **Blob Access Tier** | Hot | Optimized for frequently accessed data |

**Screenshot — Configuration Settings (Part 1):**

![Configuration Settings 1](assets/storagela1-configuration-1.png)

**Screenshot — Configuration Settings (Part 2):**

![Configuration Settings 2](assets/storagela1-configuration-2.png)

---

### Phase 4 — Properties & Blob Service Review

A full review of the storage account properties confirmed the following:

| Property | Value |
|---|---|
| **Blob Soft Delete** | Enabled (7 days) |
| **Container Soft Delete** | Enabled (7 days) |
| **Versioning** | Disabled |
| **Change Feed** | Disabled |
| **NFS v3** | Disabled |
| **Cross-Tenant Replication** | Disabled |
| **Public Network Access** | Enabled |
| **Network Routing** | Microsoft Network Routing |

**Screenshot — Full Properties & Blob Service Settings:**

![storagela1 Properties](assets/storagela1-properties.png)

---

### Phase 5 — Azure Advisor Recommendations (Security Findings)

Azure Advisor flagged **4 active recommendations** for the storage account — all directly relevant to security hardening:

| Recommendation | Impact | Category | Finding |
|---|---|---|---|
| Enable zone redundancy for storage accounts | **High** | Reliability | Current redundancy model does not include zone-level protection |
| Storage accounts should prevent shared key access | **Medium** | Security | Shared key access enabled — recommend switching to Entra ID-based auth |
| Storage accounts should restrict network access using virtual network rules | **Medium** | Security | Public network access open — should be restricted to trusted networks |
| Storage account should use a private link connection | **Medium** | Security | No private endpoint configured — data accessible over public internet |

**Screenshot — Azure Advisor Recommendations:**

![Advisor Recommendations](assets/storagela1-advisor.png)

#### SOC Analyst Perspective on These Findings

As a SOC Analyst, these recommendations translate directly into real-world security risks:

| Finding | Risk | Recommended Action |
|---|---|---|
| No zone redundancy | Service disruption during zone failure | Upgrade to ZRS or GZRS |
| Shared key access enabled | Key compromise = full account access | Disable and enforce Entra ID auth |
| Open network access | Exposed attack surface | Restrict to VNet or specific IP ranges |
| No private link | Data traverses public internet | Configure private endpoint |

---

### Phase 6 — Diagnostic Settings

Diagnostic settings were reviewed to assess logging coverage across storage services:

| Resource | Resource Type | Diagnostics Status |
|---|---|---|
| storagela1 | Storage account | Disabled |
| blob | Storage account | ✅ Enabled |
| queue | Storage account | Disabled |
| table | Storage account | Disabled |
| file | Storage account | Disabled |

> **Observation:** Only blob diagnostics are enabled. For a production environment, enabling diagnostics across all storage services (queue, table, file) would be recommended to ensure full audit coverage — a critical requirement under compliance frameworks such as NIST 800-53 and PCI-DSS.

**Screenshot — Diagnostic Settings:**

![Diagnostic Settings](assets/storagela1-diagnostics.png)

---

## Key Observations

**Storage is strategic, not just operational.**
The redundancy model selected at creation time directly determines how resilient your data is to failures — a decision that cannot be changed easily after deployment.

**Small configurations have large downstream impact.**
Disabling public blob access or enforcing secure transfer may seem minor, but these settings are the difference between a secure environment and an exposed one.

**Azure Advisor is a powerful security tool.**
The 4 recommendations flagged by Advisor represent real security gaps — open network access, shared key usage, and missing private endpoints are among the most common cloud misconfigurations found in real-world environments.

**Logging gaps are a compliance risk.**
With only blob diagnostics enabled, queue, table, and file activity goes unlogged — creating blind spots that would be flagged in any security audit.

---

## Security Relevance for SOC Analysts

| Scenario | SOC Relevance |
|---|---|
| Public blob access enabled | Data exposure risk — potential misconfiguration alert |
| Unusual storage access patterns | Indicator of compromise or data exfiltration |
| Disabled secure transfer | Unencrypted data in transit — compliance violation |
| Excessive key usage | Potential credential abuse or unauthorized access |
| LRS used for sensitive data | Business continuity risk — flag as a security finding |
| Diagnostics disabled | Logging blind spot — limits incident investigation capability |
| Open network access | Expanded attack surface — VNet restriction recommended |

---

## Key Takeaways

- Azure Storage Accounts are the backbone of cloud data infrastructure — not a peripheral service
- Redundancy models must be chosen deliberately based on availability and recovery requirements
- Security configurations at the storage layer are critical to preventing data exposure
- Azure Advisor provides actionable, prioritized security findings — a valuable tool for SOC analysts reviewing cloud posture
- Diagnostic logging gaps create blind spots that limit incident response and compliance reporting
- Every configuration decision made today has architectural and security implications tomorrow

---

## Skills Demonstrated

`Microsoft Azure` `Azure Storage Accounts` `Cloud Infrastructure` `Data Redundancy`
`Cloud Security` `Security Configuration` `Azure Portal` `LRS / ZRS / GRS / RA-GRS / GZRS`
`Azure Advisor` `Diagnostic Settings` `Misconfiguration Detection` `NIST 800-53` `ISO 27001` `PCI-DSS`

---

*Part of an ongoing series of hands-on Azure and cybersecurity labs. See repository for additional projects.*
